/*************************************************
2-D Euler solver curvilinear grid
Madhu Sreedhar           01/22/07
**************************************************/
/* System Include files---------------*/
#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#include<math.h>
#include<string.h>

/******************Global ***** Variables***************/
/*Global Constants*/
#define az       100
#define IMAX	100
#define JMAX	100
#define PI      4.*atan(1.0)
#define GAMMA	1.4
#define S1		110.4/293.		// or 273 Madhu

double EPS	=	5.0E-05;
double RE	=	10000.0;
double MACH=	1.1;
double PR	=	0.7;

int RESTART_FLAG=0;
int FILE_OPEN=0;
int  VISCOUS = 0;
int MAX_ITER= 2000;
int MAX_TIME =200;
int PRINT_FREQ =16000;
int GRID_FLAG =5;				/* 1-cartesian, 2-cyl, 3-hump*/

/* Boundary values */
double UINF=1.0;
double VINF=0.0;
double RINF=1.0;
double TINF=1.0;
double PINF=TINF*RINF/(GAMMA*MACH*MACH);
double AINF2=GAMMA*PINF/RINF;
double UJLOW=0.0;
double VJLOW=0.0;

/*Primary Variables*/
double u[IMAX][JMAX], v[IMAX][JMAX], r[IMAX][JMAX],t[IMAX][JMAX];
double un[IMAX][JMAX], vn[IMAX][JMAX], rn[IMAX][JMAX],tn[IMAX][JMAX];
double uold[IMAX][JMAX], vold[IMAX][JMAX], 
rold[IMAX][JMAX],told[IMAX][JMAX];
int temp_to_energy_flag=0;

/*Fluxes*/
double inv_u[IMAX][JMAX], inv_v[IMAX][JMAX],
inv_r[IMAX][JMAX],inv_t[IMAX][JMAX];

/*Viscous Fluxes*/
double tauxx[IMAX][JMAX], tauyy[IMAX][JMAX], tauxy[IMAX][JMAX];

/*Grid Variables*/
double jacob[IMAX][JMAX], x[IMAX][JMAX], y[IMAX][JMAX];
double xx[IMAX][JMAX], xy[IMAX][JMAX], yx[IMAX][JMAX],yy[IMAX][JMAX];
//int imax=144,jmax=60;
//  int imax=287,jmax=60;
//  int imax=70,jmax=12;
//    int imax=136,jmax=27;
int imax=81, jmax=81;

/*Temporal Variable/ Time advancement*/
double time=0,dt=0.01,cfl=0.7;
long int counter;
//	double a=1./4.,A=8./15.,b=0,B=5./12.,c=3./4.;
double rk3a=1./4.,rk3A=2./3.,rk3b=3./20.,rk3B=5./12.,rk3c=3./5.,rk3C=0;

/*Files*/
FILE *gridfile, *uvel, *vvel, *rho, *tempr, *xyplotfile1, *xyplotfile2, 
*streamline, *vortfile, *pressurefile;

char gridfilename[az]="gridfile.txt",uvelfilename[az]="uvel.txt";
char vvelfilename[az]="vvel.txt",rhofilename[az]="rho.txt";
char temprfilename[az]="temperature.txt",pressurefilename[az]="pressure.txt";
char xplotfilename[az]="xaxisplot.txt",yplotfilename[az]="yaxisplot.txt";
char streamfilename[az]="streamline.txt",vortfilename[az]="vorticity.txt";

/*Other variables*/
double vorticity[IMAX][JMAX];

/*User Include files*/
#include "compact1.h"
#include "NavSt2Dcurv.h"

int main(int argc, char * argv[])
{
	int i,j;
	int stop_run=0;
	if(GRID_FLAG==4)
		read_grid();
	else
		grid_gen(GRID_FLAG,imax,jmax);
	initialize_variables(argc,argv,imax,jmax);
	open_files();
	compute_jacobian(imax,jmax);
	compute_total_energy(u,v,r,t,imax,jmax);
	compute_total_energy(un,vn,rn,tn,imax,jmax);
	while(time<MAX_TIME && counter<MAX_ITER && !stop_run)
	{
	 	if(counter==counter/PRINT_FREQ*PRINT_FREQ) print_profiles(0);
		dt=compute_time_step();
		time=time+dt;
		counter++;
		if(VISCOUS)compute_viscid_flux(u,v,r,t,imax,jmax);
		compute_inviscid_flux(u,v,r,t,imax,jmax);
		perform_runge_kutta_steps(rk3A,u,v,r,t,un,vn,rn,tn,imax,jmax);
		perform_runge_kutta_steps(rk3a,u,v,r,t,u,v,r,t,imax,jmax);
	 	apply_boundary_conditions(imax,jmax);

		if(VISCOUS)compute_viscid_flux(un,vn,rn,tn,imax,jmax);
		compute_inviscid_flux(un,vn,rn,tn,imax,jmax);
		perform_runge_kutta_steps(rk3B,u,v,r,t,un,vn,rn,tn,imax,jmax);
		perform_runge_kutta_steps(rk3b,u,v,r,t,u,v,r,t,imax,jmax);
	 	apply_boundary_conditions(imax,jmax);

		if(VISCOUS)compute_viscid_flux(un,vn,rn,tn,imax,jmax);
		compute_inviscid_flux(un,vn,rn,tn,imax,jmax);
		perform_runge_kutta_steps(rk3c,u,v,r,t,u,v,r,t,imax,jmax);
		perform_runge_kutta_steps(rk3C,u,v,r,t,un,vn,rn,tn,imax,jmax);
 	  	apply_filter(u,v,r,t,imax,jmax);
		stop_run=compute_residual(u,v,r,t,un,vn,rn,tn,imax,jmax);
		for(j=0;j<jmax;j++)
			for(i=0;i<imax;i++)
			{
				uold[i][j]=u[i][j];
				vold[i][j]=v[i][j];
				rold[i][j]=r[i][j];
				told[i][j]=t[i][j];
			}
		apply_boundary_conditions(imax,jmax);
	}
	print_profiles(1);
	write_variables();
	return 0;
}




