/*XXXXXXXXXXXXXXXXXX----XXXXXXXXXXXXXXXXXXXXXXXXX
Header file for the 2-D Euler Solver
XXXXXXXXXXXXXXXXXXXX----XXXXXXXXXXXXXXXXXXXXXXXXX*/

/******************************************
Open the files
*******************************************/
int open_files()  //Flag=> 1=cartesian,2=cylindrical,3=hump
{
	char Read_Write[3]="w+";
	if(RESTART_FLAG) strcpy(Read_Write,"r+");
	if(FILE_OPEN==1) return 0;
	if((xyplotfile1=fopen(xplotfilename,"w"))==NULL)
	{
		printf("\nCould not open xyplot1file");
		exit(999);
	}
	if((streamline=fopen(streamfilename,"w"))==NULL)
	{
		printf("\nCould not open streamline");
		exit(999);
	}
	if((vortfile=fopen(vortfilename,"w"))==NULL)
	{
		printf("\nCould not open vorticity");
		exit(999);
	}
	if((pressurefile=fopen(pressurefilename,"w"))==NULL)
	{
		printf("\nCould not open pressure");
		exit(999);
	}
	if((xyplotfile2=fopen(yplotfilename,"w"))==NULL)
	{
		printf("\nCould not open xyplot2file");
		exit(999);
	}
	if((gridfile=fopen(gridfilename,Read_Write))==NULL)
	{
		printf("\nCould not open gridfile");
		exit(999);
	}
	if((uvel=fopen(uvelfilename,Read_Write))==NULL)
	{
		printf("\nCould not open uvel");
		exit(999);
	}
	if((vvel=fopen(vvelfilename,Read_Write))==NULL)
	{
		printf("\nCould not open vvel");
		exit(999);
	}
	if((rho=fopen(rhofilename,Read_Write))==NULL)
	{
		printf("\nCould not open rho");
		exit(999);
	}
	if((tempr=fopen(temprfilename,Read_Write))==NULL)
	{
		printf("\nCould not open temperature");
		exit(999);
	}
	FILE_OPEN=1;
	return 0;
}
/******************************************
Grid from file
*******************************************/
int read_grid()
{
	int i,j;
	FILE * grid;
	float floatx,floaty;
	//if((grid=fopen("airfoil_coarse.txt","r"))==NULL)
	if((grid=fopen("airfoil_medium.txt","r"))==NULL)
	{
		printf("\nCould not open grid file");
		exit(999);
	}
	//fscanf(grid,"%d %d",&imax,&jmax);
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i+=1)
		{
			fscanf(grid,"\n%f %f",&floatx,&floaty);
			x[i][j]=floatx;
			y[i][j]=floaty;
	 	//	printf("\n%f %f",x[i][j],y[i][j]);
		}
	}
	return 0;
}
/******************************************
Generate the Grid
*******************************************/
int grid_gen(int flag,int imax,int jmax)  //Flag=> 1=cartesian,2=cylindrical,3=hump
{
	int i,j;
	double dx=0.2;
	double dy=0.2;
	double rad=0.5;
	double dr=0.01;
	double radius=1.0,theta=0;
	double temp1,temp2;
	if(RESTART_FLAG) return 0;
	if(flag==1 || flag==5)
	{
		temp1=dx;
		temp2=dy;
		for(j=0;j<jmax;j++)
		{
			for(i=0;i<imax;i++)
			{
				x[i][j]=temp1*(i-imax/2);
				temp1=temp1*1.00;
			}
			temp1=dx;
		}
		for(i=0;i<imax;i++)
		{
			for(j=0;j<jmax;j++)
			{
				y[i][j]=temp2*(j-jmax/2);
				temp2=temp2*1.00;
			}
			temp2=dy;
		}
		for(i=40;i<imax-10;i++)
		{
			for(j=15;j<jmax-15;j++)
			{
		 		x[i][j]=x[i][j]+sin(double(i*j))/100*1.0;
		 		y[i][j]=y[i][j]+sin(double(i*j))/100*1.0;
			}
		}
	}
	else if(flag==2)
	{
		for(j=0;j<jmax;j++)
		{
			temp1=8.0-7.0/((double)(jmax-1))*(double)j;
		//	temp1=1.0;
			radius=radius+dr;
			dr=dr*1.10;
			for(i=0;i<imax;i++)
			{
				theta=2.*PI/(double)(imax-1)*i;
				x[i][j]=radius*cos(theta);
				y[i][j]=radius*sin(theta)/temp1;
	//			printf("\n%f %f %f %f",radius,theta,x[i][j],y[i][j]);
			}
		}
	}
	else if(flag==3)
	{
		dx=0.2;
		dy=0.1;
		temp1=dx;
		temp2=dy;
		for(j=0;j<jmax;j++)
		{
			for(i=0;i<imax;i++)
			{
				x[i][j]=temp1*i;
				temp1=temp1*1.00;
			}
			temp1=dx;
		}
		for(i=0;i<imax;i++)
		{
			temp2=dy;
			temp1=-sin(6./2.*PI*x[i][0]/(x[imax-1][0]-x[0][0]))/1.;
			if(temp1<0) temp1=0;
			for(j=0;j<jmax;j++)
			{
				y[i][j]=temp2*j;
				temp1=temp1*exp(-y[i][j]/10);
				y[i][j]=y[i][j]+temp1;
				temp2=temp2*1.04;
			}
		}
	}

	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			printf("\n%2d %2d %12f %12f",i,j,x[i][j],y[i][j]);
		}
	}
	return 0;
}
/**************************************************
compute T from E
***************************************************/
int compute_temperature(double u[][JMAX],double v[][JMAX],double
r[][JMAX],double t[][JMAX],int imax,int jmax)
{
	int i,j;
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			t[i][j]=GAMMA*(GAMMA-1)*MACH*MACH*
				(t[i][j]/r[i][j]-((u[i][j]*u[i][j]+v[i][j]*v[i][j])*0.5));
		}
	}
	return 0;
}
/**************************************************
compute  E from T
***************************************************/
int compute_total_energy(double u[][JMAX],double v[][JMAX],double
r[][JMAX],double t[][JMAX],int imax,int jmax)
{
	int i,j;
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			t[i][j]=(t[i][j]/(GAMMA*(GAMMA-1)*MACH*MACH)+
				(u[i][j]*u[i][j]+v[i][j]*v[i][j])*0.5)*r[i][j];
		}
	}
	return 0;
}
/******************************************
Compute DT min
*******************************************/
double compute_time_step()
{
	int i,j;
	double dtx=100.0,dty=100.0;
	double dtvx=100.0,dtvy=100.0;
	double dtmin;
	//DTXV=CFL*D(I,J,K)*(DX/AJX(I))**2*(GAMMA-1)*MACH*MACH*PR/AMUV
	double tempx,tempy,tempvx,tempvy;
	double tempmu,tij;

	compute_temperature(u,v,r,t,imax,jmax);
	for(j=0;j<jmax;j++)
	{
		if(VISCOUS)
		{
			for(i=0;i<imax-1;i++)
			{
				tij=GAMMA*(GAMMA-1)*MACH*MACH*
					(t[i][j]/r[i][j]-((u[i][j]*u[i][j]+v[i][j]*v[i][j])*0.5));
		 		tempmu  = tij*sqrt(tij)*(1.+S1)/(tij+S1)/RE;
				tempx=x[i+1][j]-x[i][j];
				if(GRID_FLAG==2 || GRID_FLAG==4)tempx=sqrt(pow((y[i+1][j]-y[i][j]),2)+pow((x[i+1][j]-x[i][j]),2))/2;
				tempvx=cfl*r[i][j]*(tempx*tempx)*(GAMMA-1)*MACH*MACH*PR/tempmu;
				if(tempvx<dtvx) dtvx=tempvx;
				if(tempvx<=0)
					printf("\nXV %d %d %f %f",i,j,x[i][j],t[i][j]);
			}
		}

		for(i=0;i<imax-1;i++)
		{

			tempx=x[i+1][j]-x[i][j];
			if(GRID_FLAG==2 || GRID_FLAG==4 )tempx=sqrt(pow((y[i+1][j]-y[i][j]),2)+pow((x[i+1][j]-x[i][j]),2))/2;
			tempx=cfl*fabs(tempx)/(fabs(u[i][j])+sqrt(t[i][j])/MACH);
			if(tempx<dtx) dtx=tempx;
			if(tempx<=0)
				printf("\nX %d %d %f %f",i,j,x[i][j],t[i][j]);
		}
	}
	for(i=0;i<imax;i++)
	{
		for(j=0;j<jmax-1;j++)
		{
			tempy=fabs((y[i][j+1]-y[i][j]));
			if(GRID_FLAG==2 || GRID_FLAG==4)tempy=sqrt(pow((y[i][j+1]-y[i][j]),2)+pow((x[i][j+1]-x[i][j]),2))/2;
			tempy=cfl*tempy/(fabs(v[i][j])+sqrt(t[i][j])/MACH);
			if(tempy<=0)
				printf("\nY %d %d %f %f",i,j,y[i][j],t[i][j]);
			if(tempy<dty) dty=tempy;
		}
		if(VISCOUS)
		{
			for(j=0;j<jmax-1;j++)
			{
				tij=GAMMA*(GAMMA-1)*MACH*MACH*
					(t[i][j]/r[i][j]-((u[i][j]*u[i][j]+v[i][j]*v[i][j])*0.5));
		 		tempmu  = tij*sqrt(tij)*(1.+S1)/(tij+S1)/RE;
				tempy=y[i][j+1]-y[i][j];
				if(GRID_FLAG==2 || GRID_FLAG==4)tempy=sqrt(pow((y[i][j+1]-y[i][j]),2)+pow((x[i][j+1]-x[i][j]),2))/2;
				tempvy=cfl*r[i][j]*tempy*tempy*(GAMMA-1)*MACH*MACH*PR/tempmu;
				if(tempvy<dtvy) dtvy=tempvy;
				if(tempvy<=0)
					printf("\nYV %d %d %f %f",i,j,y[i][j],t[i][j]);
			}
		}
	}
	dtmin=dtx;
	if(dty<dtmin) dtmin=dty;
	if(VISCOUS)
	{
		if(dtvy<dtmin) dtmin=dtvy;
		if(dtvx<dtmin) dtmin=dtvx;
	}
//	printf("\n%d %10f %10f %10f %10f %10f",counter,dtx,dty,dtvx,dtvy,dtmin);
	compute_total_energy(u,v,r,t,imax,jmax);
	return dtmin;
}
/******************************************
Initialize the variables
*******************************************/
int initialize_variables(int argc, char *argv[],int imax,int jmax)
{
	int i,j,k;
	FILE *infile;
	char in_rec[200];
	char temp[200],temp1[200];
	double x_core=-3.0,dx,dy,ds,F_core,u_sound;
	double y_core=0.0, A_core=1.0, al_core=1.;
	if(argc>1)
	{
		if((infile=fopen(argv[1],"r"))==NULL)
		{
			printf("\n Could not Open input file, taking default values");
		}
	}
	if(infile!=NULL)
	{
		while(fgets(in_rec,200,infile)!=NULL)
		{
			memset(temp,'\0',200);
			memset(temp1,'\0',200);
			if(strstr(in_rec,"RE")!=NULL)
			{
				k=sscanf(in_rec,"%s,%s",temp1, temp);
				RE=atof(temp1);
			}
			if(strstr(in_rec,"MACH")!=NULL) 
			{
				k=sscanf(in_rec,"%s,%s",temp1, temp);
				MACH=atof(temp1);
			}
			if(strstr(in_rec,"PR")!=NULL) 
			{
				k=sscanf(in_rec,"%s,%s",temp1, temp);
				PR=atof(temp1);
			}
			if(strstr(in_rec,"EPS")!=NULL) 
			{
				k=sscanf(in_rec,"%s,%s",temp1, temp);
				EPS=atof(temp1);
			}
			if(strstr(in_rec,"VISCOUS")!=NULL) 
			{
				k=sscanf(in_rec,"%s,%s",temp1, temp);
				VISCOUS=atof(temp1);
			}
			if(strstr(in_rec,"CFL")!=NULL) 
			{
				k=sscanf(in_rec,"%s,%s",temp1, temp);
				cfl=atof(temp1);
			}
			if(strstr(in_rec,"MAX_ITER")!=NULL) 
			{
				sscanf(in_rec,"%d",&MAX_ITER, temp);
			}

			if(strstr(in_rec,"MAX_TIME")!=NULL) sscanf(in_rec,"%d %s",&MAX_TIME, temp);
			if(strstr(in_rec,"PRINT_FREQ")!=NULL) sscanf(in_rec,"%d %s",&PRINT_FREQ, temp);
			if(strstr(in_rec,"GRID_FLAG")!=NULL) sscanf(in_rec,"%d %s",&GRID_FLAG, temp);
			if(strstr(in_rec,"RESTART")!=NULL) sscanf(in_rec,"%d %s",&RESTART_FLAG, temp);


			if(strstr(in_rec,"GRIDFILE")!=NULL) sscanf(in_rec,"%s,%s",gridfilename, temp);
			if(strstr(in_rec,"UVEL")!=NULL) sscanf(in_rec,"%s,%s",uvelfilename, temp);
			if(strstr(in_rec,"VVEL")!=NULL) sscanf(in_rec,"%s,%s",vvelfilename, temp);
			if(strstr(in_rec,"RHO")!=NULL) sscanf(in_rec,"%s,%s",rhofilename, temp);
			if(strstr(in_rec,"TEMPERATURE")!=NULL) sscanf(in_rec,"%s,%s",temprfilename, temp);
			if(strstr(in_rec,"PRESSURE")!=NULL) sscanf(in_rec,"%s,%s",pressurefilename, temp);
			if(strstr(in_rec,"XAXISPLOT")!=NULL) sscanf(in_rec,"%s,%s",xplotfilename, temp);
			if(strstr(in_rec,"YAXISPLOT")!=NULL) sscanf(in_rec,"%s,%s",yplotfilename, temp);
			if(strstr(in_rec,"STREAMLINE")!=NULL) sscanf(in_rec,"%s,%s",streamfilename, temp);
			if(strstr(in_rec,"VORTICITY")!=NULL) sscanf(in_rec,"%s,%s",vortfilename, temp);
			memset(in_rec,'\0',200);
		}
	}
	printf("\nRe=%g, Mach=%g, Pr=%g, Eps=%g, CFL=%g",
		RE,MACH,PR,EPS,cfl);
	printf("\nMax iter=%d, Grid flag=%d, Max time=%d, Print Freq=%d, Viscous=%d, Restart=%d",
		MAX_ITER,GRID_FLAG,MAX_TIME, PRINT_FREQ, VISCOUS, RESTART_FLAG);
	open_files();
	if(!RESTART_FLAG)
	{
		for(j=0;j<jmax;j++)
		{
			for(i=0;i<imax;i++)
			{
				dy=y[i][j]-y_core;
				dx=x[i][j]-x_core;
				ds=(dy*dy+dx*dx);
				F_core=pow(A_core,2)/(4.*al_core)*exp(-2.*al_core*ds);
				u[i][j]=UINF*1.0-dy*A_core*exp(-al_core*ds);
				v[i][j]=VINF*1.0+dx*A_core*exp(-al_core*ds);
				r[i][j]=RINF*0.0+pow((1.0-(GAMMA-1)/AINF2*F_core),(1./(GAMMA-1.)));
				t[i][j]=TINF*0.0+(1.0-(GAMMA-1)/AINF2*F_core);
				if(j==jmax/2) printf("\n%02d %02d %+10f %+10f %+10f %+10f %+10f %+10f",
					i,j,x[i][j],y[i][j],u[i][j],v[i][j],r[i][j],t[i][j]);
			}
		}
	}

	if(RESTART_FLAG)
	{
		memset(temp,'\0',200);
		fscanf(gridfile,"%s",temp);
		time=atof(temp);
		memset(temp,'\0',200);
		memset(temp1,'\0',200);
		fscanf(gridfile,"\n%s %s",temp,temp1);
		imax=atoi(temp);
		jmax=atoi(temp1);
		for(int j=0;j<jmax;j++)
		{
			for(int i=0;i<imax;i++)
			{
				memset(temp,'\0',200);
				memset(temp1,'\0',200);
				fscanf(gridfile,"\n%s %s",temp,temp1);
				x[i][j]=atof(temp);
				y[i][j]=atof(temp1);

				memset(temp,'\0',200);
				fscanf(uvel,"\n%s",temp);
				u[i][j]=atof(temp);

				memset(temp,'\0',200);
				fscanf(vvel,"\n%s",temp);
				v[i][j]=atof(temp);

				memset(temp,'\0',200);
				fscanf(rho,"\n%s",temp);
				r[i][j]=atof(temp);

				memset(temp,'\0',200);
				fscanf(tempr,"\n%s",temp);
				t[i][j]=atof(temp);
			}
		}
	}
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			uold[i][j]=u[i][j];
			vold[i][j]=v[i][j];
			rold[i][j]=r[i][j];
			told[i][j]=t[i][j];
			un[i][j]=u[i][j];
			vn[i][j]=v[i][j];
			rn[i][j]=r[i][j];
			tn[i][j]=t[i][j];
				if(i==imax/2) printf("\n%02d %02d %+10f %+10f %+10f %+10f",
					i,j,x[i][j],y[i][j],u[i][j],v[i][j]);
		}
	}
	return 0;
}
/**************************************************
Compute the jacobian at all the grid points
*************************************************/
int compute_jacobian(int imax,int jmax)
{
	int i,j;
	int ijmax=imax;
	if(jmax>imax)ijmax=jmax;
	double *a1,*b1,*c1,*d1;
	double temp1,temp2;
	a1=(double *)malloc(ijmax*sizeof(double));
	b1=(double *)malloc(ijmax*sizeof(double));
	c1=(double *)malloc(ijmax*sizeof(double));
	d1=(double *)malloc(ijmax*sizeof(double));

	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			a1[i]=x[i][j];
			c1[i]=y[i][j];
		}
		if(GRID_FLAG==2)
		{
			compact6p(a1,b1,1.0,imax-1,3);
			compact6p(c1,d1,1.0,imax-1,3);
		}
		else
		{
			compact55655(a1,b1,1.0,imax,3);
			compact55655(c1,d1,1.0,imax,3);
		}
 
		for(i=0;i<imax;i++)
		{
			xx[i][j]=b1[i];
			yx[i][j]=d1[i];
	// 		fprintf(gridfile,"\n%02d %02d x=%+08f\t y=%+08f\t xx=%+08f\t yx=%+08f",
	//			i,j,x[i][j],y[i][j],xx[i][j],yx[i][j]);
		}
	}

	for(i=0;i<imax;i++)
	{
		for(j=0;j<jmax;j++)
		{
			a1[j]=x[i][j];
			c1[j]=y[i][j];

		}
		compact55655(a1,b1,1.0,jmax,3);
		compact55655(c1,d1,1.0,jmax,3);
		for(j=0;j<jmax;j++)
		{
			xy[i][j]=b1[j];
			yy[i][j]=d1[j];
	//		fprintf(gridfile,"\n%02d %02d x=%+08f\t y=%+08f\t xy=%+08f\t yy=%+08f",
	//				i,j,x[i][j],y[i][j],xy[i][j],yy[i][j]);
		}
	}


	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			temp1=0.0;
			temp2=0.0;
			jacob[i][j]=1.0/(xx[i][j]*yy[i][j]-xy[i][j]*yx[i][j]);
			temp1=xx[i][j];
			temp2=xy[i][j];
			xx[i][j]=jacob[i][j]*yy[i][j];
			yy[i][j]=jacob[i][j]*temp1;
			xy[i][j]=-jacob[i][j]*xy[i][j];
			yx[i][j]=-jacob[i][j]*yx[i][j];
	  		fprintf(gridfile,"\n%02d %02d X=%08f Y=%08f XX=%+09f XY=%+09f YX=%+09f YY=%+09f J=%09f",
	 			i,j,x[i][j],y[i][j],xx[i][j],xy[i][j],yx[i][j],yy[i][j],jacob[i][j]);
		}
	}
	return 0;
}
/**************************************************
Compute the viscous flux at all the grid points
*************************************************/
int compute_viscid_flux(double u[][JMAX],double v[][JMAX],double
r[][JMAX],double t[][JMAX],int imax,int jmax)
{
	int i,j;
	double temprx=0,tempux=0,tempvx=0,temptx=0;
	double tempry=0,tempuy=0,tempvy=0,tempty=0;
	double tempp=0,tempe=0,tempqx=0,tempqy=0,tij=0;
//	double gamma_mach=GAMMA*MACH*MACH;
//	double gamma_m1=GAMMA-1.0;
	double temp_mu;

	double QX[IMAX][JMAX],QY[IMAX][JMAX];
	double UX[IMAX][JMAX],UY[IMAX][JMAX];
	double VX[IMAX][JMAX],VY[IMAX][JMAX];
	double q1[IMAX],q2[JMAX];
	double q1x[IMAX],q2y[JMAX];
	double u1[IMAX],u2[JMAX];
	double u1x[IMAX],u2y[JMAX];
	double v1[IMAX],v2[JMAX];
	double v1x[IMAX],v2y[JMAX];

	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			tij=GAMMA*(GAMMA-1)*MACH*MACH*
				(t[i][j]/r[i][j]-((u[i][j]*u[i][j]+v[i][j]*v[i][j])*0.5));
			QX[i][j]=tij;
			QY[i][j]=tij;
			UX[i][j]=u[i][j];
			VX[i][j]=v[i][j];
			UY[i][j]=u[i][j];
			VY[i][j]=v[i][j];
		}
	}
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			u1[i]=UX[i][j];
			v1[i]=VX[i][j];
			q1[i]=QX[i][j];
		}
		if(GRID_FLAG==2 || GRID_FLAG==5)
		{
			compact6p(q1,q1x,1.0,imax-1,3);
			compact6p(u1,u1x,1.0,imax-1,3);
			compact6p(v1,v1x,1.0,imax-1,3);
		}
		else
		{
			compact55655(q1,q1x,1.0,imax,3);
			compact55655(u1,u1x,1.0,imax,3);
			compact55655(v1,v1x,1.0,imax,3);
		}
		for(i=0;i<imax;i++)
		{
			QX[i][j]=q1x[i];
			UX[i][j]=u1x[i];
			VX[i][j]=v1x[i];
		}
	}
	for(i=0;i<imax;i++)
	{
		for(j=0;j<jmax;j++)
		{
			q2[j]=QY[i][j];
			u2[j]=UY[i][j];
			v2[j]=VY[i][j];
		}
		if(GRID_FLAG==5)
		{
			compact6p(q2,q2y,1.0,jmax-1,3);
			compact6p(u2,u2y,1.0,jmax-1,3);
			compact6p(v2,v2y,1.0,jmax-1,3);
		}
		else
		{
			compact55655(q2,q2y,1.0,jmax,3);
			compact55655(u2,u2y,1.0,jmax,3);
			compact55655(v2,v2y,1.0,jmax,3);
		}
		for(j=0;j<jmax;j++)
		{
			QY[i][j]=q2y[j];
			UY[i][j]=u2y[j];
			VY[i][j]=v2y[j];
		}
	}
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			tij=GAMMA*(GAMMA-1)*MACH*MACH*
				(t[i][j]/r[i][j]-((u[i][j]*u[i][j]+v[i][j]*v[i][j])*0.5));
			temp_mu=tij*sqrt(tij)*(1.+S1)/(tij+S1)/RE*1.0;  // Madhu Add RE
		//	tempp=tij*r[i][j]/GAMMA/MACH/MACH;
		//	tempe=tempp/r[i][j]/gamma_m1;
		//	tempE=r[i][j]*((u[i][j]*u[i][j]+v[i][j]*v[i][j])*0.5+tempe);
			tempqx=(QX[i][j]*xx[i][j]+QY[i][j]*yx[i][j])*temp_mu/((GAMMA-1)*MACH*MACH*RE*PR);
			tempqy=(QX[i][j]*yx[i][j]+QY[i][j]*yy[i][j])*temp_mu/((GAMMA-1)*MACH*MACH*RE*PR);
			tauxx[i][j]=2.0*temp_mu/3./RE*
				 ( 2.0* (UX[i][j]*xx[i][j]+UY[i][j]*yx[i][j]) +
				 (-1.0* (VX[i][j]*xy[i][j]+VY[i][j]*yy[i][j])));
			tauyy[i][j]=2.0*temp_mu/3./RE*
				 (-1.0* (UX[i][j]*xx[i][j]+UY[i][j]*yx[i][j]) -
				 ( 2.0* (VX[i][j]*xy[i][j]+VY[i][j]*yy[i][j])));
			tauxy[i][j]=1.0*temp_mu/1./RE*
				 ( 1.0* (UY[i][j]*yy[i][j]+UX[i][j]*xy[i][j]) -
				 ( 1.0* (VX[i][j]*xx[i][j]+VY[i][j]*yx[i][j])));
			vorticity[i][j]=(-(UY[i][j]*yy[i][j]+UX[i][j]*xy[i][j]) +
				 (VX[i][j]*xx[i][j]+VY[i][j]*yx[i][j]));
			QX[i][j]=tempqx;
			QY[i][j]=tempqy;
		}
	}
	return 0;
}
/**************************************************
Compute the inviscid flux at all the grid points
*************************************************/
int compute_inviscid_flux(double u[][JMAX],double v[][JMAX],double r[][JMAX],double t[][JMAX],int imax,int jmax)
{
	int i,j;
	double temprx=0,tempux=0,tempvx=0,temptx=0;
	double tempry=0,tempuy=0,tempvy=0,tempty=0;
	double tempp=0,tempe=0,tempE,tempqx=0,tempqy=0,tij=0;
	double gamma_mach=GAMMA*MACH*MACH;
	double gamma_m1=GAMMA-1.0;
	double temp_mu;

	double E1[IMAX][JMAX],E2[IMAX][JMAX],E3[IMAX][JMAX],E4[IMAX][JMAX];
	double F1[IMAX][JMAX],F2[IMAX][JMAX],F3[IMAX][JMAX],F4[IMAX][JMAX];
 	double QX[IMAX][JMAX],QY[IMAX][JMAX];
	double e1[IMAX],e2[IMAX],e3[IMAX],e4[IMAX];
	double e1x[IMAX],e2x[IMAX],e3x[IMAX],e4x[IMAX];
	double f1[JMAX],f2[JMAX],f3[JMAX],f4[JMAX];
	double f1y[JMAX],f2y[JMAX],f3y[JMAX],f4y[JMAX];
 	double q1[IMAX],q2[JMAX];
	double q1x[IMAX],q2y[JMAX];

  	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			tij=GAMMA*(GAMMA-1)*MACH*MACH*
				(t[i][j]/r[i][j]-((u[i][j]*u[i][j]+v[i][j]*v[i][j])*0.5));
			QX[i][j]=tij;
			QY[i][j]=tij;
			q1[i]=tij;
		}
		if(GRID_FLAG==2 || GRID_FLAG==5)
		{
			compact6p(q1,q1x,1.0,imax-1,3);
		}
		else
		{
			compact55655(q1,q1x,1.0,imax,3);
		}
		for(i=0;i<imax;i++)
		{
			QX[i][j]=q1x[i];
		}
	}
	for(i=0;i<imax;i++)
	{
		for(j=0;j<jmax;j++)
		{
			q2[j]=QY[i][j];
		}
		if(GRID_FLAG==5)
		{
			compact6p(q2,q2y,1.0,jmax-1,3);
		}
		else
		{
			compact55655(q2,q2y,1.0,jmax,3);
		}
		for(j=0;j<jmax;j++)
		{
			QY[i][j]=q2y[j];
		}
	}
	 
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			tempqx=0;
			tempqy=0;
			tij=GAMMA*(GAMMA-1)*MACH*MACH*
				(t[i][j]/r[i][j]-((u[i][j]*u[i][j]+v[i][j]*v[i][j])*0.5));
			temp_mu=tij*sqrt(tij)*(1.+S1)/(tij+S1)/RE*1.0;  // Madhu Add RE
			tempp=tij*r[i][j]/GAMMA/MACH/MACH;
			tempe=tempp/r[i][j]/gamma_m1;
			tempE=r[i][j]*((u[i][j]*u[i][j]+v[i][j]*v[i][j])*0.5+tempe);
	//		tempqx=(QX[i][j]*xx[i][j]+QY[i][j]*xy[i][j])*temp_mu/((GAMMA-1)*MACH*MACH*RE*PR);
	//		tempqy=(QX[i][j]*yx[i][j]+QY[i][j]*yy[i][j])*temp_mu/((GAMMA-1)*MACH*MACH*RE*PR);
			temprx=r[i][j]*u[i][j];
			tempry=r[i][j]*v[i][j];
			tempux=r[i][j]*u[i][j]*u[i][j]+tempp-tauxx[i][j]*VISCOUS;
			tempuy=r[i][j]*u[i][j]*v[i][j]-tauxy[i][j]*VISCOUS;
			tempvx=r[i][j]*u[i][j]*v[i][j]-tauxy[i][j]*VISCOUS;
			tempvy=r[i][j]*v[i][j]*v[i][j]+tempp-tauyy[i][j]*VISCOUS;
			temptx=(tempE+tempp)*u[i][j]-VISCOUS*(u[i][j]*tauxx[i][j]+v[i][j]*tauxy[i][j])-tempqx*VISCOUS; 
//Madhu Q in EUler
			tempty=(tempE+tempp)*v[i][j]-VISCOUS*(u[i][j]*tauxy[i][j]+v[i][j]*tauyy[i][j])-tempqy*VISCOUS;
			E1[i][j]=(temprx*xx[i][j]+tempry*xy[i][j])/jacob[i][j];
			E2[i][j]=(tempux*xx[i][j]+tempuy*xy[i][j])/jacob[i][j];
			E3[i][j]=(tempvx*xx[i][j]+tempvy*xy[i][j])/jacob[i][j];
			E4[i][j]=(temptx*xx[i][j]+tempty*xy[i][j])/jacob[i][j];
			F1[i][j]=(temprx*yx[i][j]+tempry*yy[i][j])/jacob[i][j];
			F2[i][j]=(tempux*yx[i][j]+tempuy*yy[i][j])/jacob[i][j];
			F3[i][j]=(tempvx*yx[i][j]+tempvy*yy[i][j])/jacob[i][j];
			F4[i][j]=(temptx*yx[i][j]+tempty*yy[i][j])/jacob[i][j];
		/*	inv_r[i][j]=temprx*xx[i][j]+tempry*xy[i][j]+temprx*yx[i][j]+tempry*yy[i][j];
			inv_u[i][j]=tempux*xx[i][j]+tempuy*xy[i][j]+tempux*yx[i][j]+tempuy*yy[i][j];
			inv_v[i][j]=tempvx*xx[i][j]+tempvy*xy[i][j]+tempvx*yx[i][j]+tempvy*yy[i][j];
			inv_t[i][j]=temptx*xx[i][j]+tempty*xy[i][j]+temptx*yx[i][j]+tempty*yy[i][j];
			printf("\nff%d %d %f %f %f %f %f %f %f
%f",i,j,u[i][j],v[i][j],r[i][j],t[i][j],
				inv_u[i][j],inv_v[i][j],inv_r[i][j],inv_t[i][j]);*/
	     /*  		printf("\nff%d %d %9g %9g %9g %9g %9g %9g %9g
%9g",i,j,E1[i][j],F1[i][j],E2[i][j],F2[i][j],
	   	   			E3[i][j],F3[i][j],E4[i][j],F4[i][j]);*/
		}
	}

	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			e1[i]=E1[i][j];
			e2[i]=E2[i][j];
			e3[i]=E3[i][j];
			e4[i]=E4[i][j];
		}
		if(GRID_FLAG==2 || GRID_FLAG==5)
		{
			compact6p(e1,e1x,1.0,imax-1,3);
			compact6p(e2,e2x,1.0,imax-1,3);
			compact6p(e3,e3x,1.0,imax-1,3);
			compact6p(e4,e4x,1.0,imax-1,3);
		}
		else
		{
			compact55655(e1,e1x,1.0,imax,3);
			compact55655(e2,e2x,1.0,imax,3);
			compact55655(e3,e3x,1.0,imax,3);
			compact55655(e4,e4x,1.0,imax,3);
		}
		for(i=0;i<imax;i++)
		{
/*	 	printf("\nEEB %02d %02d %+012.8f %+012.8f %+012.8f %+012.8f",
			i,j,E1[i][j],E2[i][j],E3[i][j],E4[i][j]);*/
			E1[i][j]=e1x[i];
			E2[i][j]=e2x[i];
			E3[i][j]=e3x[i];
			E4[i][j]=e4x[i];
/*	   	printf("\nEEA %02d %02d %+012.8f %+012.8f %+012.8f %+012.8f",
			i,j,E1[i][j],E2[i][j],E3[i][j],E4[i][j]);*/
		}
	}
	for(i=0;i<imax;i++)
	{
		for(j=0;j<jmax;j++)
		{
			f1[j]=F1[i][j];
			f2[j]=F2[i][j];
			f3[j]=F3[i][j];
			f4[j]=F4[i][j];
		}
		if(GRID_FLAG==5)
		{
			compact6p(f1,f1y,1.0,jmax-1,3);
			compact6p(f2,f2y,1.0,jmax-1,3);
			compact6p(f3,f3y,1.0,jmax-1,3);
			compact6p(f4,f4y,1.0,jmax-1,3);
		}
		else
		{
			compact55655(f1,f1y,1.0,jmax,3);
			compact55655(f2,f2y,1.0,jmax,3);
			compact55655(f3,f3y,1.0,jmax,3);
			compact55655(f4,f4y,1.0,jmax,3);
		}
		for(j=0;j<jmax;j++)
		{
			F1[i][j]=f1y[j];
			F2[i][j]=f2y[j];
			F3[i][j]=f3y[j];
			F4[i][j]=f4y[j];
/*			printf("\nFF%02d %02d %+012.8f %+012.8f %+012.8f %+012.8f",
			i,j,F1[i][j],F2[i][j],F3[i][j],F4[i][j]);*/
		}
	}
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			inv_r[i][j]=(E1[i][j]+F1[i][j]);
			inv_u[i][j]=(E2[i][j]+F2[i][j]);
			inv_v[i][j]=(E3[i][j]+F3[i][j]);
			inv_t[i][j]=(E4[i][j]+F4[i][j]);
	 //         		printf("\ninv%02d %02d %+012.8f %+012.8f %+012.8f %+012.8f",
	   //    	 		i,j,inv_u[i][j],inv_v[i][j],inv_r[i][j],inv_t[i][j]);
	/*        		printf("\nf%02d %02d %+08.3e %+08.3e %+08.3e %+08.3e %+08.3e
%+08.3e %+08.3e %+08.3e"
	 					,i,j,E2[i][j],F2[i][j],E3[i][j],F3[i][j],
	      	 		inv_u[i][j],inv_v[i][j],inv_r[i][j],inv_t[i][j]);*/
		}
	}

	return 0;
}
/**************************************************
Perform Runge Kutta step
*************************************************/
int perform_runge_kutta_steps(double var,double u[][JMAX],double v[][JMAX],
							double r[][JMAX],double t[][JMAX],
							double un[][JMAX],double vn[][JMAX],
							double rn[][JMAX],double tn[][JMAX],int imax,int jmax)
{
	int i_start=1, i_end=imax-1;
	int j_start=1, j_end=jmax-1;
	int i,j;
	double temp_r;
	if(GRID_FLAG==2 || GRID_FLAG==5) /* O-Grid == Periodic*/
	{
		i_start=0;
		i_end=imax;
	}
	if(GRID_FLAG==5)
	{
		j_start=0;
		j_end=jmax;
	}
	for(j=j_start;j<j_end;j++)
	{
		for(i=i_start;i<i_end;i++)
		{
			temp_r=r[i][j];
			un[i][j]=(temp_r*u[i][j]/jacob[i][j]-var*dt*inv_u[i][j])*jacob[i][j];
			vn[i][j]=(temp_r*v[i][j]/jacob[i][j]-var*dt*inv_v[i][j])*jacob[i][j];
			rn[i][j]=(       r[i][j]/jacob[i][j]-var*dt*inv_r[i][j])*jacob[i][j];
			tn[i][j]=(       t[i][j]/jacob[i][j]-var*dt*inv_t[i][j])*jacob[i][j];
			un[i][j]=un[i][j]/rn[i][j];
			vn[i][j]=vn[i][j]/rn[i][j];
/*			printf("\n%d %d %f %f %f %f %f %f %f
%f",i,j,u[i][j],v[i][j],r[i][j],t[i][j],
				inv_u[i][j],inv_v[i][j],inv_r[i][j],inv_t[i][j]);*/
		}
	}
	return 0;
}
/******************************************
Apply the boundary conditions
*******************************************/
int apply_boundary_conditions(int imax,int jmax)
{
	int i,j;
	double dx,dy,ds;

	compute_temperature(u,v,r,t,imax,jmax);
	compute_temperature(un,vn,rn,tn,imax,jmax);

	if(GRID_FLAG==2 ) // O Grid----------
	{
		j=0;
		for(i=0;i<imax;i++)
		{
			dy=y[i+1][j]-y[i][j];
			dx=x[i+1][j]-x[i][j];
			ds=sqrt(dy*dy+dx*dx);
			u[i][j]=u[i][j+1]*dx/ds;
			v[i][j]=v[i][j+1]*dy/ds;
			r[i][j]=r[i][j+1];
			t[i][j]=t[i][j+1];
			un[i][j]=un[i][j+1]*dx/ds;
			vn[i][j]=vn[i][j+1]*dy/ds;
			rn[i][j]=rn[i][j+1];
			tn[i][j]=tn[i][j+1];
		}
		i=0;
		for(j=1;j<jmax-1;j++)
		{
			u[i][j]=u[imax-1][j];
			v[i][j]=v[imax-1][j];
			r[i][j]=r[imax-1][j];
			t[i][j]=t[imax-1][j];
			un[i][j]=un[imax-1][j];
			vn[i][j]=vn[imax-1][j];
			rn[i][j]=rn[imax-1][j];
			tn[i][j]=tn[imax-1][j];
		}
		j=jmax;
		for(i=0;i<imax-1;i++)
		{
			dy=y[i+1][j]-y[i][j];
			dx=x[i+1][j]-x[i][j];
			ds=sqrt(dy*dy+dx*dx);
			if(dy>=0.0)
			{
				u[i][j]=UINF*1.0;
				v[i][j]=VINF*1.0;
				r[i][j]=RINF;
				t[i][j]=TINF;
				un[i][j]=UINF*1.0;
				vn[i][j]=VINF*1.0;
				rn[i][j]=RINF;
				tn[i][j]=TINF;
			}
			else
			{
				u[i][j]=u[i][j-1];
				un[i][j]=un[i][j-1];
				v[i][j]=v[i][j-1];
				vn[i][j]=vn[i][j-1];
				t[i][j]=t[i][j-1];
				tn[i][j]=tn[i][j-1];
				r[i][j]=r[i][j-1];
				rn[i][j]=rn[i][j-1];
			}
		}
	}
	else if(GRID_FLAG==4)//C -Grid-----------
	{
		i=imax-1;
		for(j=1;j<jmax-1;j++)
		{
			u[i][j]=u[i-1][j]*1.0;
			v[i][j]=v[i-1][j]*1.0;
			r[i][j]=r[i-1][j] ;
			t[i][j]=t[i-1][j] ;
			un[i][j]=un[i-1][j]*1.0;
			vn[i][j]=vn[i-1][j]*1.0;
			rn[i][j]=rn[i-1][j];
			tn[i][j]=tn[i-1][j];
		}
		i=0;
		for(j=1;j<jmax-1;j++)
		{
			u[i][j]=u[i+1][j]*1.0;
			v[i][j]=v[i+1][j]*1.0;
			r[i][j]=r[i+1][j] ;
			t[i][j]=t[i+1][j] ;
			un[i][j]=un[i+1][j]*1.0;
			vn[i][j]=vn[i+1][j]*1.0;
			rn[i][j]=rn[i+1][j];
			tn[i][j]=tn[i+1][j];

		}
		j=0;
		for(i=0;i<imax;i++)
		{
			u[i][j]=u[i][j+1]*0.0;
			v[i][j]=v[i][j+1]*0.0;
			r[i][j]=r[i][j+1];
			t[i][j]=t[i][j+1];
			un[i][j]=un[i][j+1]*0.0;
			vn[i][j]=vn[i][j+1]*0.0;
			rn[i][j]=rn[i][j+1];
			tn[i][j]=tn[i][j+1];
		}
		j=jmax;
		for(i=0;i<imax-1;i++)
		{
			dy=y[i+1][j]-y[i][j];
			dx=x[i+1][j]-x[i][j];
			ds=sqrt(dy*dy+dx*dx);
			if(dy>=0.0)
			{
				u[i][j]=UINF*1.0;
				v[i][j]=VINF*1.0;
				r[i][j]=RINF;
				t[i][j]=TINF;
				un[i][j]=UINF*1.0;
				vn[i][j]=VINF*1.0;
				rn[i][j]=RINF;
				tn[i][j]=TINF;
			}
			else
			{
				u[i][j]=u[i][j-1];
				un[i][j]=un[i][j-1];
				v[i][j]=v[i][j-1];
				vn[i][j]=vn[i][j-1];
				t[i][j]=t[i][j-1];
				tn[i][j]=tn[i][j-1];
				r[i][j]=r[i][j-1];
				rn[i][j]=rn[i][j-1];
			}

		}
	}
	else // Algebraic grids
	{
		if(GRID_FLAG!=5)//Madhu
		{
			i=imax-1;
			for(j=1;j<jmax-1;j++)
			{
				u[i][j]=u[i-1][j]*1.0;
				v[i][j]=v[i-1][j]*1.0;
				r[i][j]=r[i-1][j] ;
				t[i][j]=t[i-1][j] ;
				un[i][j]=un[i-1][j]*1.0;
				vn[i][j]=vn[i-1][j]*1.0;
				rn[i][j]=rn[i-1][j];
				tn[i][j]=tn[i-1][j];
			}
			i=0;
			for(j=1;j<jmax-1;j++)
			{
				u[i][j]=UINF*1.0;
				v[i][j]=VINF*1.0;
				r[i][j]=RINF;
				t[i][j]=TINF;
				un[i][j]=UINF*1.0;
				vn[i][j]=VINF*1.0;
				rn[i][j]=RINF;
				tn[i][j]=TINF;
			}
			j=jmax-1;
			for(i=0;i<imax;i++)
			{
				u[i][j]=UINF*1.0;
				v[i][j]=VINF*1.0;
				r[i][j]=r[i][j-1];
				t[i][j]=t[i][j-1];
				un[i][j]=UINF*1.0;
				vn[i][j]=VINF*1.0;
				rn[i][j]=rn[i][j-1];
				tn[i][j]=tn[i][j-1];
			}
			j=0;
			for(i=0;i<imax;i++)
			{
				u[i][j]=u[i][j+1]*1.0;
				v[i][j]=v[i][j+1]*1.0;
				r[i][j]=r[i][j+1];
				t[i][j]=t[i][j+1];
				un[i][j]=un[i][j+1]*1.0;
				vn[i][j]=vn[i][j+1]*1.0;
				rn[i][j]=rn[i][j+1];
				tn[i][j]=tn[i][j+1];
			}
		}
		if(GRID_FLAG==5)
		{
			j=0;
			for(i=0;i<imax;i++)
			{
				u[i][j]=u[i][jmax-1];
				v[i][j]=v[i][jmax-1];
				r[i][j]=r[i][jmax-1];
				t[i][j]=t[i][jmax-1];
				un[i][j]=un[i][jmax-1];
				vn[i][j]=vn[i][jmax-1];
				rn[i][j]=rn[i][jmax-1];
				tn[i][j]=tn[i][jmax-1];
			}
			i=0;
			for(j=1;j<jmax;j++)
			{
				u[i][j]=u[imax-1][j];
				v[i][j]=v[imax-1][j];
				r[i][j]=r[imax-1][j];
				t[i][j]=t[imax-1][j];
				un[i][j]=un[imax-1][j];
				vn[i][j]=vn[imax-1][j];
				rn[i][j]=rn[imax-1][j];
				tn[i][j]=tn[imax-1][j];
			}
		}
	 /*	j=jmax/2;
		for(i=imax/3;i<imax/3*2;i++)
		{
			u[i][j]=u[i][j-1]*0.0;
			un[i][j]=un[i][j-1]*0.0;
			v[i][j]=v[i][j-1]*0.0;
			vn[i][j]=vn[i][j-1]*0.0;
		}
	//	u[imax/3-1][j]=0;
	//	un[imax/3-1][j]=0; */
	}

	compute_total_energy(u,v,r,t,imax,jmax);
	compute_total_energy(un,vn,rn,tn,imax,jmax);
	return 0;
}
/**************************************************
Compute the residual
*************************************************/
double compute_residual(double u[][JMAX],double v[][JMAX],
							double r[][JMAX],double t[][JMAX],
							double un[][JMAX],double vn[][JMAX],
							double rn[][JMAX],double tn[][JMAX],int imax,int jmax)
{
	int i,j;
	double umax=0,vmax=0,rmax=0,tmax=0;
	int iumax=0,ivmax=0,itmax=0,irmax=0;
	int jumax=0,jvmax=0,jtmax=0,jrmax=0;
	double UVMAX=UINF;
	if(UINF<VINF)UVMAX=VINF;
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			if(fabs(uold[i][j]-u[i][j])>umax)
			{
				umax=(fabs(uold[i][j]-u[i][j]));
				iumax=i;
				jumax=j;
			}
			if(fabs(vold[i][j]-v[i][j])>vmax)
			{
				vmax=(fabs(vold[i][j]-v[i][j]));
				ivmax=i;
				jvmax=j;
			}
			if(fabs(rold[i][j]-r[i][j])>rmax)
			{
				rmax=(fabs(rold[i][j]-r[i][j]));
				irmax=i;
				jrmax=j;
			}
			if(fabs(told[i][j]-t[i][j])>tmax)
			{
				tmax=(fabs(told[i][j]-t[i][j]));
				itmax=i;
				jtmax=j;
			}
	/*		umax=umax+(fabs(un[i][j]-u[i][j]));
			vmax=vmax+(fabs(vn[i][j]-v[i][j]));
			rmax=rmax+(fabs(rn[i][j]-r[i][j]));
			tmax=tmax+(fabs(tn[i][j]-t[i][j]));*/
/*			if( (counter==counter/100*100) && (i==0 || i==imax/2 || i==imax-1))
				printf("\n%d %d,%f %f Values=%g %g %g %g",
				i,j,x[i][j],y[i][j],un[i][j],vn[i][j],rn[i][j],tn[i][j]);*/
		//	if(un[i][j]>3.0*UVMAX  || vn[i][j]>3.0*UVMAX)
		//		printf("\n%02d %02d,Large Values=%+09f %+09f %+09f %+09f",
		//			i,j,un[i][j],vn[i][j],rn[i][j],tn[i][j]);
		}
	}
	if(counter==counter/1*1)
	 	printf("\n%04d %02d %02d %06g %02d %02d %06g %02d %02d %06g %02d %02d %06g %6g T=%06g",
		counter,iumax,jumax,umax,ivmax,jvmax,vmax,irmax,jrmax,rmax,itmax,jtmax,tmax,dt,time);
	return 0;
	if(umax < EPS && vmax < EPS && rmax < EPS && tmax < EPS)
		return 1;
}
/*******************************************************
Apply the filter
********************************************************/
int apply_filter(double u[][JMAX],double v[][JMAX],double r[][JMAX],double
t[][JMAX],int imax,int jmax)
{
	int i,j;
	double e1[IMAX],e2[IMAX],e3[IMAX],e4[IMAX];
	double e1x[IMAX],e2x[IMAX],e3x[IMAX],e4x[IMAX];
	double f1[JMAX],f2[JMAX],f3[JMAX],f4[JMAX];
	double f1y[JMAX],f2y[JMAX],f3y[JMAX],f4y[JMAX];

	//compute_total_energy(u,v,r,t,imax,jmax);
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			u[i][j]=u[i][j]*r[i][j]/jacob[i][j];
			v[i][j]=v[i][j]*r[i][j]/jacob[i][j];
			t[i][j]=t[i][j]/jacob[i][j];
			r[i][j]=r[i][j]/jacob[i][j];
		}
	}
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			e1[i]=u[i][j];
			e2[i]=v[i][j];
			e3[i]=r[i][j];
			e4[i]=t[i][j];
		}
		if(GRID_FLAG==8 || GRID_FLAG==6) //Madhu
		{
			filter10p(e1,e1x,1.0,imax,0.1);
			filter10p(e2,e2x,1.0,imax,0.1);
			filter10p(e3,e3x,1.0,imax,0.1);
			filter10p(e4,e4x,1.0,imax,0.1);
		}
		else
		{
			filter246X642(e1,e1x,1.0,imax,0.1);
			filter246X642(e2,e2x,1.0,imax,0.1);
			filter246X642(e3,e3x,1.0,imax,0.1);
			filter246X642(e4,e4x,1.0,imax,0.1);
		}
		for(i=0;i<imax;i++)
		{
			if(fabs(u[i][j]-e1x[i])>4.*fabs(u[i][j])) 
				printf("\nXFilt,%d,%d,%f,%f",i,j,u[i][j],e1x[i]);
			u[i][j]=e1x[i];
			v[i][j]=e2x[i];
			r[i][j]=e3x[i];
			t[i][j]=e4x[i];
		}
	}
	for(i=0;i<imax;i++)
	{
		for(j=0;j<jmax;j++)
		{
			f1[j]=u[i][j];
			f2[j]=v[i][j];
			f3[j]=r[i][j];
			f4[j]=t[i][j];
		}
		if(GRID_FLAG==6)
		{
			filter10p(f1,f1y,1.0,jmax,0.1);
			filter10p(f2,f2y,1.0,jmax,0.1);
			filter10p(f3,f3y,1.0,jmax,0.1);
			filter10p(f4,f4y,1.0,jmax,0.1);
		}
		else
		{
			filter246X642(f1,f1y,1.0,jmax,0.1);
			filter246X642(f2,f2y,1.0,jmax,0.1);
			filter246X642(f3,f3y,1.0,jmax,0.1);
			filter246X642(f4,f4y,1.0,jmax,0.1);
		}
		for(j=0;j<jmax;j++)
		{
			if(fabs(u[i][j]-f1y[j])>4.*fabs(u[i][j])) 
				printf("\nYFilt,%d,%d,%f,%f",i,j,u[i][j],f1y[j]);
			u[i][j]=f1y[j];
			v[i][j]=f2y[j];
			r[i][j]=f3y[j];
			t[i][j]=f4y[j];
		}
	}
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			r[i][j]=r[i][j]*jacob[i][j];
			u[i][j]=u[i][j]/r[i][j]*jacob[i][j];
			v[i][j]=v[i][j]/r[i][j]*jacob[i][j];
			t[i][j]=t[i][j]*jacob[i][j];
		}
	}
	return 0;
}
/*******************************************************
Print profiles
********************************************************/
void print_profiles(int last_flag)
{
	int i,j;
	double psi[IMAX][JMAX], tempp;

	if(last_flag)
	{
		compute_viscid_flux(u,v,r,t,imax,jmax);
		compute_temperature(u,v,r,t,imax,jmax);
	}
		for(i=0,j=jmax/2;i<imax;i++)
		{
			printf("\n%10f %10f %+10f",time,x[i][j],u[i][j]);
			fprintf(xyplotfile1,"\n%10f %10f %10f %+10f %+10f %+10f %+10f",
				time,x[i][j],y[i][j],u[i][j],v[i][j],r[i][j],t[i][j]);
		}
		for(i=0;i<imax;i+=imax/2)
		{
			for(j=0;j<jmax;j++)
			{
				printf("\n%10f %10f %+10f",time,y[i][j],u[i][j]);
				fprintf(xyplotfile2,"\n%10f %10f %10f %+10f %+10f %+10f %+10f",
					time,x[i][j],y[i][j],u[i][j],v[i][j],r[i][j],t[i][j]);
			}
		}
		if(!last_flag)return ;
	/* Compute stream lines*/
		for(j=0;j<jmax;j++)
		{
			for(i=0;i<imax;i++)
			{
				psi[i][j]=0.0;
			}
		}
		for(j=1;j<jmax;j++)
		{
			for(i=0;i<imax;i++)
			{
				psi[i][j]=psi[i][j-1]-(y[i][j]-y[i][j-1])*(u[i][j]);
			}
		}
		/*Prints streamline and vorticity*/
		fprintf(streamline,"\n%d %d",imax,jmax);
		fprintf(vortfile,"\n%d %d",imax,jmax);
		fprintf(pressurefile,"\n%d %d",imax,jmax);
		for(j=0;j<jmax;j++)
		{
			for(i=0;i<imax;i++)
			{
				tempp=t[i][j]*r[i][j]/GAMMA/MACH/MACH;
				fprintf(streamline,"\n%0f %0f %0f",x[i][j],y[i][j],r[i][j]);
				fprintf(pressurefile,"\n%0f %0f %0f",x[i][j],y[i][j],tempp);
				fprintf(vortfile,"\n%0f %0f %0f",x[i][j],y[i][j],vorticity[i][j]);
			}
		}
		compute_total_energy(u,v,r,t,imax,jmax);
}
/*******************************************************
Write out variables
********************************************************/
void write_variables()
{
	int i,j;
	compute_temperature(u,v,r,t,imax,jmax);
	rewind(uvel);
	rewind(vvel);
	rewind(rho);
	rewind(tempr);
	rewind(gridfile);
	fprintf(gridfile,"%+16f\n",time);
	fprintf(gridfile,"%d  %d\n",imax,jmax);
	for(j=0;j<jmax;j++)
	{
		for(i=0;i<imax;i++)
		{
			fprintf(gridfile,"%+16f %+16f\n",x[i][j],y[i][j]);
			fprintf(uvel,"%+16f\n",u[i][j]);
			fprintf(vvel,"%+16f\n",v[i][j]);
			fprintf(rho,"%+16f\n",r[i][j]);
			fprintf(tempr,"%+16f\n",t[i][j]);
		}
	}
	fprintf(gridfile,"\n");

	for(i=0,j=jmax/2;i<imax && counter==counter/1*1;i++)
	{
		printf("\n%10f %10f %+10f",time,x[i][j],u[i][j]);
		fprintf(xyplotfile1,"\n%10f %10f %+10f %+10f %+10f %+10f",
			time,x[i][j],u[i][j],v[i][j],r[i][j],t[i][j]);
	}

	for(j=0,i=imax/2;j<jmax && counter==counter/1*1;j++)
	{
		printf("\n%10f %10f %+10f",time,y[i][j],u[i][j]);
		fprintf(xyplotfile2,"\n%10f %10f %+10f %+10f %+10f %+10f",
			time,y[i][j],u[i][j],v[i][j],r[i][j],t[i][j]);
	}

	compute_total_energy(u,v,r,t,imax,jmax);
}



