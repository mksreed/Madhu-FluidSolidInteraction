10000.0,        	 RE
0.2,            	 MACH
0.7,             	PR
1 ,               	GRID_FLAG
0.00001,    	 EPS
0  ,              	VISCOUS
100 ,           	 MAX_ITER
200,          	MAX_TIME
10000 ,            	PRINT_FREQ
0.5 ,           	CFL
0,		RESTART
gridfile.txt	GRIDFILE
uvel.txt		UVEL
vvel.txt		VVEL
rho.txt		RHO
temperature.txt	TEMPERATURE
pressure.txt	PRESSURE
xaxisplot.txt	XAXISPLOT
yaxisplot.txt	YAXISPLOT
streamline.txt	STREAMLINE
vorticity.txt	VORTICITY

