int triad(double a[],double b[],double c[],double xx[],double d[],int imaxx)
{
	int i=0;
	//	printf("\nxx%d %f %f %f %f",i, a[i],b[i],c[i],d[i]);
	for(i=1;i<imaxx;i++)
	{
	//	printf("\nxx%d %f %f %f %f",i, a[i],b[i],c[i],d[i]);
		b[i]=b[i]-c[i-1]*a[i]/b[i-1];
		d[i]=d[i]-d[i-1]*a[i]/b[i-1];
		a[i]=a[i]-b[i-1]*a[i]/b[i-1];
	// 	printf("\nxx%d %f %f %f %f",i, a[i],b[i],c[i],d[i]);
	}
	xx[imaxx-1]=d[imaxx-1]/b[imaxx-1];
	for(i=imaxx-2;i>=0;i--)
	{
		xx[i]=(d[i]-c[i]*xx[i+1])/b[i];
	}
	return 0;
}
int triadp(double a[],double b[],double c[],double xx[],double d[],int
imaxx)
{
	// Needs to be worked upon
	int i=0;
	int imax=imaxx;
	double temp;
/*
	for(i=0;i<imaxx;i++)
	{
		printf("\nXX%d %f %f %f %f",i, a[i],b[i],c[i],d[i]);
	}
*/
	for(i=1;i<imaxx;i++)
	{
		b[i]=b[i]-c[i-1]*a[i]/b[i-1];
		d[i]=d[i]-d[i-1]*a[i]/b[i-1];
		a[i]=a[i]-b[i-1]*a[i]/b[i-1];
	//	printf("\n%d %f %f %f %f",i, a[i],b[i],c[i],d[i]);
	}

	for(i=0;i<imaxx;i++)
	{
//		printf("\nY%d %f %f %f %f",i, a[i],b[i],c[i],d[i]);
		c[i]=c[i]/b[i];
		a[i]=a[i]/b[i];
		d[i]=d[i]/b[i];
		b[i]=b[i]/b[i];
	//	printf("\nYY%d %f %f %f %f",i, a[i],b[i],c[i],d[i]);
	}


	 /*  special logic for periodic functions */
  	b[imax-1]=b[imax-1]-a[0]/b[0]*c[imax-1];
	d[imax-1]=d[imax-1]-d[0]/b[0]*c[imax-1];
	temp=-c[0]/b[0]*c[imax-1];
	for(i=1;i<imax-2;i++)
	{
		d[imax-1]=d[imax-1]-temp*d[i]/b[i];
		b[imax-1]=b[imax-1]-temp*0.0;
		temp=-temp*c[i]/b[i];
		printf("\nYYY%d %f %f %f",i,temp,b[i],d[i]);
	}
	i=imax-2;
	d[imax-1]=d[imax-1]-temp*d[i]/b[i];
	b[imax-1]=b[imax-1]-temp*c[i]/b[i];
	temp=-temp*c[i];
	/* Back Substitution*/
	xx[imaxx-1]=d[imaxx-1]/b[imax-1];
	for(i=imaxx-2;i>0;i--)
	{
		xx[i]=(d[i]-c[i]*xx[i+1])/b[i];
	}
	i=0;
	xx[i]=(d[i]-c[i]*xx[i+1]-a[i]*xx[imax-1])/b[i];
	return 0;
}
int compact33633(double f[],double fx[],double dx,int imax,int
boundary_flag)
{
	/*Boundary_flag (Default=0, Periodic=1, zero stress=2)*/
	double alpha=1./3., a=14.0/9.0, b=1.0/9.0;
	double *a1,*b1,*c1,*d1,*e1;
	int i;
	a1=(double *)malloc(imax*sizeof(double));
	b1=(double *)malloc(imax*sizeof(double));
	c1=(double *)malloc(imax*sizeof(double));
	d1=(double *)malloc(imax*sizeof(double));
	e1=(double *)malloc(imax*sizeof(double));

	for(i=2;i<imax-2;i++)
	{
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		d1[i]=0.0;
		e1[i]=a/2.*(f[i+1]-f[i-1])+b/4.*(f[i+2]-f[i-2]);
	}
	if(boundary_flag==1) /* Periodic Boundary */
	{
		i=0;
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		d1[i]=0;
		e1[i]=a/2.*(f[i+1]-f[imax-1])+b/4.*(f[i+2]-f[imax-2]);
		i=imax-1;
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		d1[i]=0;
		e1[i]=a/2.*(f[0]-f[i-1])+b/4.*(f[1]-f[i-2]);
		i=1;
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		d1[i]=0;
		e1[i]=a/2.*(f[i+1]-f[i-1])+b/4.*(f[i+2]-f[imax-1]);
		i=imax-2;
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		d1[i]=0;
		e1[i]=a/2.*(f[imax-1]-f[i-1])+b/4.*(f[0]-f[i-2]);
	}
	else if(boundary_flag==2)/* zero stress */
	{
		i=0;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=0.0;
		i=1;
		a1[i]=0;
		b1[i]=1.0;
		c1[i]=2.0*1.0;
	 	e1[i]=1./2./dx*(-5.0*f[i]+4.0*f[i+1]+f[i+2]);
		i=imax-2;
		a1[i]=2.0*1.0;
		b1[i]=1.0;
		c1[i]=0.0;
	 	e1[i]=-1./2./dx*(-5.0*f[i]+4.0*f[i-1]+f[i-2]);
		i=imax-1;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=0.0;
	}
	else		/* Default Boundary Condition */
	{
		i=0;
		a1[i]=0;
		b1[i]=1.0;
		c1[i]=2.0*1.0;
		e1[i]=1./2./dx*(-5.0*f[i]+4.0*f[i+1]+f[i+2]);
		i=1;
		a1[i]=0;
		b1[i]=1.0;
		c1[i]=2.0*1.0;
	 	e1[i]=1./2./dx*(-5.0*f[i]+4.0*f[i+1]+f[i+2]);
		i=imax-1;
		a1[i]=2.0*1.0;
		b1[i]=1.0;
		c1[i]=0.0;
	 	e1[i]=-1./2./dx*(-5.0*f[i]+4.0*f[i-1]+f[i-2])*1.0;
		i=imax-2;
		a1[i]=2.0*1.0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=-1./2./dx*(-5.0*f[i]+4.0*f[i-1]+f[i-2])*1.0;
	}
	if(boundary_flag==1)
		triadp(a1,b1,c1,d1,e1,imax);
	else
		triad(a1,b1,c1,d1,e1,imax);
	for(i=0;i<imax;i++)
	{
		fx[i]=d1[i];
//	 	if(fx[i]*fx[i]<EPS) fx[i]=0.0;
	}
	free(a1);
	free(b1);
	free(c1);
	free(d1);
	free(e1);
	return 0;
}
int compact45654(double f[],double fx[],double dx,int imax,int
boundary_flag)
{
	/*Boundary_flag (Default=0, zero stress=2)*/
	double alpha=1./3., a=14.0/9.0, b=1.0/9.0;
	double *a1,*b1,*c1,*d1,*e1;
	int i;
	a1=(double *)malloc(imax*sizeof(double));
	b1=(double *)malloc(imax*sizeof(double));
	c1=(double *)malloc(imax*sizeof(double));
	d1=(double *)malloc(imax*sizeof(double));
	e1=(double *)malloc(imax*sizeof(double));

	for(i=2;i<imax-2;i++)
	{
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		d1[i]=0.0;
		e1[i]=a/2.*(f[i+1]-f[i-1])+b/4.*(f[i+2]-f[i-2]);
	}
	if(boundary_flag==2)/* zero stress */
	{
		i=0;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=0.0;
		i=1;
		a1[i]=3.0/14.;
		b1[i]=1.0;
		c1[i]=3.0/14.;

	e1[i]=1./dx*(-19./28.*f[i-1]-5./42.*f[i]+6./7.*f[i+1]-1./14.*f[i+2]+1./84*f[i+3]);
		i=imax-2;
		a1[i]=2.0*1.0;
		b1[i]=1.0;
		c1[i]=0.0;
	 	e1[i]=-1./2./dx*(-5.0*f[i]+4.0*f[i-1]+f[i-2]);
		i=imax-1;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=0.0;
	}
	else		/* Default Boundary Condition */
	{
		i=0;
		a1[i]=0;
		b1[i]=1.0;
		c1[i]=3.0;
		e1[i]=1./dx*(-17./6.*f[i]+3./2.*f[i+1]+3./2.*f[i+2]-1./6.*f[i+3]);

		i=1;
		a1[i]=3.0/14.;
		b1[i]=1.0;
		c1[i]=3.0/14.;

	e1[i]=1./dx*(-19./28.*f[i-1]-5./42.*f[i]+6./7.*f[i+1]-1./14.*f[i+2]+1./84*f[i+3]);

	/*	 i=imax-1;
		a1[i]=2.0*1.0;
		b1[i]=1.0;
		c1[i]=0.0;
	 	e1[i]=-1./2./dx*(-5.0*f[i]+4.0*f[i-1]+f[i-2]); */
	 	i=imax-1;
		a1[i]=3.0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=1./dx*(+17./6.*f[i]-3./2.*f[i-1]-3./2.*f[i-2]+1./6.*f[i-3]);

	/*	i=imax-2;
		a1[i]=2.0*1.0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=-1./2./dx*(-5.0*f[i]+4.0*f[i-1]+f[i-2]);*/
		i=imax-2;
		a1[i]=3.0/14.;
		b1[i]=1.0;
		c1[i]=3.0/14.;

	e1[i]=1./dx*(+19./28.*f[i+1]+5./42.*f[i]-6./7.*f[i-1]+1./14.*f[i-2]-1./84*f[i-3]);
	}
	if(boundary_flag==1)
		triadp(a1,b1,c1,d1,e1,imax);
	else
		triad(a1,b1,c1,d1,e1,imax);
	for(i=0;i<imax;i++)
	{
		fx[i]=d1[i];
	}
	free(a1);
	free(b1);
	free(c1);
	free(d1);
	free(e1);
	return 0;
}
int filter10(double f[],double fx[],double dx,int imax,double alpha)
{
	double a00,a01,a02,a03,a04,a05;
	double a40,a41,a42,a43;

	double b12,b22,b32,b42,b52,b62,b72;
	double b13,b23,b33,b43,b53,b63,b73;

	double *a1,*b1,*c1,*d1,*e1;
	int i;
	a1=(double *)malloc(imax*sizeof(double));
	b1=(double *)malloc(imax*sizeof(double));
	c1=(double *)malloc(imax*sizeof(double));
	d1=(double *)malloc(imax*sizeof(double));
	e1=(double *)malloc(imax*sizeof(double));
	alpha=0.40;  //Madhu

	/* pre-boundary points */
	a40= 11./16.+05.*alpha/08.;
	a41= 15./32.+17.*alpha/16.;
	a42=-03./16.+03.*alpha/08.;
	a43= 01./32.-01.*alpha/16.;

	/* middle points */
	a00=      ( 193.+126.*alpha)/256.;
	a01=      ( 105.+302.*alpha)/256.;
	a02= 015.*(-001.+002.*alpha)/064.;
	a03= 045.*( 001.-002.*alpha)/512.;
	a04= 005.*(-001.+002.*alpha)/256.;
	a05=      ( 001.-002.*alpha)/512.;

	/* Boundary (+/-)2 */
	b13=-01./64.+01.*alpha/32.;
	b23= 03./32.+13.*alpha/16.;
	b33= 49./64.+15.*alpha/32.;
	b43= 05./16.+03.*alpha/08.;
	b53=-15./64.+15.*alpha/32.;
	b63= 03./32.-03.*alpha/16.;
	b73=-01./64.+01.*alpha/32.;

	/* Boundary(+/-) 1 */
	b12= 01./64.+31.*alpha/32.;
	b22= 29./32.+03.*alpha/16.;
	b32= 15./64.+17.*alpha/32.;
	b42=-05./16.+05.*alpha/08.;
	b52= 15./64.-15.*alpha/32.;
	b62=-03./32.+03.*alpha/16.;
	b72= 01./64.-01.*alpha/32.;

	for(i=5;i<=imax-6;i++)
	{
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		d1[i]=0.0;
		e1[i]=(a00*(f[i+0]+f[i-0])+
			   a01*(f[i+1]+f[i-1])+
			   a02*(f[i+2]+f[i-2])+
			   a03*(f[i+3]+f[i-3])+
			   a04*(f[i+4]+f[i-4])+
			   a05*(f[i+5]+f[i-5]))*0.5;
	}
/*Boundary Points 3,4, imax-5,imax-4*/
		for(i=3;i<=imax-4;i++)
		{
			if(i==5)i=imax-5;
			a1[i]=alpha;
			b1[i]=1.0;
			c1[i]=alpha;
			e1[i]=(a40*(f[i+0]+f[i-0])+
				   a41*(f[i+1]+f[i-1])+
				   a42*(f[i+2]+f[i-2])+
				   a43*(f[i+3]+f[i-3]))*0.5;
		}
/*Boundary Points 0,1,2, imax-3,imax-2,imax-1*/
		i=2;
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		e1[i]=b13*f[i-2]+b23*f[i-1]+b33*f[i+0]+b43*f[i+1]+b53*f[i+2]+b63*f[i+3]+b73*f[i+4];

		i=1;
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		e1[i]=b12*f[i-1]+b22*f[i-0]+b32*f[i+1]+b42*f[i+2]+b52*f[i+3]+b62*f[i+4]+b72*f[i+5];

		for(i=0;i<=0;i++)
		{
			a1[i]=0;
			b1[i]=1.0;
			c1[i]=0;
			e1[i]=f[i];
		}

		i=imax-3;
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		e1[i]=-b13*f[i+2]-b23*f[i+1]-b33*f[i+0]-b43*f[i-1]-b53*f[i-2]-b63*f[i-3]-b73*f[i-4];
		e1[i]=(( 5./8.+3./4.*alpha)*(f[i+0]+f[i-0])+
			   ( 1./2.+1./1.*alpha)*(f[i+1]+f[i-1])+
			   (-1./8.+1./4.*alpha)*(f[i+2]+f[i-2]))*0.5;

		i=imax-2;
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		e1[i]=-b12*f[i+1]-b22*f[i+0]-b32*f[i-1]-b42*f[i-2]-b52*f[i-3]-b62*f[i-4]-b72*f[i-5];
	 	e1[i]=(( 1./2.+1./1.*alpha)*(f[i+0]+f[i-0])+
	 		   ( 1./2.+1./1.*alpha)*(f[i+1]+f[i-1]))*0.5;

		for(i=imax-1;i<=imax-1;i++)
		{
			a1[i]=0;
			b1[i]=1.0;
			c1[i]=0;
			e1[i]=f[i];
		}

	triad(a1,b1,c1,d1,e1,imax);
	for(i=0;i<imax;i++)
	{
		fx[i]=d1[i];
	}
	if(a1!=NULL) free(a1);
	if(b1!=NULL)free(b1);
	if(c1!=NULL) free(c1);
	if(d1!=NULL) free(d1);
	if(e1!=NULL) free(e1);
	return 0;
}
int filter246X642(double f[],double fx[],double dx,int imax,double alpha)
{
	double a00,a01,a02,a03,a04,a05;
	double a60,a61,a62,a63;
	double a40,a41,a42;
	double a20,a21;

//	double b12,b22,b32,b42,b52,b62,b72;
//	double b13,b23,b33,b43,b53,b63,b73;

	double *a1,*b1,*c1,*d1,*e1;
	int i;
	a1=(double *)malloc(imax*sizeof(double));
	b1=(double *)malloc(imax*sizeof(double));
	c1=(double *)malloc(imax*sizeof(double));
	d1=(double *)malloc(imax*sizeof(double));
	e1=(double *)malloc(imax*sizeof(double));
	alpha=0.10;  //Madhu

	/* Boundary (+/-) 2nd order */
	a20= 01./02.+01.*alpha/01.;
	a21= 01./02.+01.*alpha/01.;

	/* pre-boundary points 4rth order*/
	a40= 05./08.+03.*alpha/04.;
	a41= 01./02.+01.*alpha/01.;
	a42=-01./08.+01.*alpha/04.;

	/* pre-boundary points 6th order*/
	a60= 11./16.+05.*alpha/08.;
	a61= 15./32.+17.*alpha/16.;
	a62=-03./16.+03.*alpha/08.;
	a63= 01./32.-01.*alpha/16.;

	/* middle points 10 order */
	a00=      ( 193.+126.*alpha)/256.;
	a01=      ( 105.+302.*alpha)/256.;
	a02= 015.*(-001.+002.*alpha)/064.;
	a03= 045.*( 001.-002.*alpha)/512.;
	a04= 005.*(-001.+002.*alpha)/256.;
	a05=      ( 001.-002.*alpha)/512.;

	for(i=5;i<=imax-6;i++)
	{
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		d1[i]=0.0;
		e1[i]=(a00*(f[i+0]+f[i-0])+
			   a01*(f[i+1]+f[i-1])+
			   a02*(f[i+2]+f[i-2])+
			   a03*(f[i+3]+f[i-3])+
			   a04*(f[i+4]+f[i-4])+
			   a05*(f[i+5]+f[i-5]))*0.5;
	}
/*Boundary Points 3,4, imax-5,imax-4*/
		for(i=3;i<=imax-4;i++)
		{
			if(i==5)i=imax-5;
			a1[i]=alpha;
			b1[i]=1.0;
			c1[i]=alpha;
			e1[i]=(a60*(f[i+0]+f[i-0])+
				   a61*(f[i+1]+f[i-1])+
				   a62*(f[i+2]+f[i-2])+
				   a63*(f[i+3]+f[i-3]))*0.5;
		}
/*Boundary Points 2, imax-3*/
		for(i=2;i<=imax-3;i++)
		{
			if(i==3)i=imax-3;
			a1[i]=alpha;
			b1[i]=1.0;
			c1[i]=alpha;
			e1[i]=(a40*(f[i+0]+f[i-0])+
				   a41*(f[i+1]+f[i-1])+
				   a42*(f[i+2]+f[i-2]))*0.5;
		}
/*Boundary Points 1,imax-2*/
		for(i=1;i<=imax-2;i++)
		{
			if(i==2)i=imax-2;
			a1[i]=alpha;
			b1[i]=1.0;
			c1[i]=alpha;
			e1[i]=(a20*(f[i+0]+f[i-0])+
				   a21*(f[i+1]+f[i-1]))*0.5;
		}

/*Boundary Points 0,imax-1*/
		for(i=0;i<=imax-1;i++)
		{
			if(i==1)i=imax-1;
			a1[i]=0.0;
			b1[i]=1.0;
			c1[i]=0.0;
			e1[i]=f[i];
		}


	triad(a1,b1,c1,d1,e1,imax);
	for(i=0;i<imax;i++)
	{
		fx[i]=d1[i];
	}
	free(a1);
	free(b1);
	free(c1);
	free(d1);
	free(e1);
	return 0;
}
int compact6p(double f[],double fx[],double dx,int imax,int boundary_flag)
{
	double alpha=1./3., a=14.0/9.0, b=1.0/9.0;
	double *a1,*b1,*c1,*d1,*e1, *q, *u, *v, *y;
	double temp1=0.0,temp2=0.0,temp3=0.0;
	int i,k;
	a1=(double *)malloc(imax*sizeof(double));
	b1=(double *)malloc(imax*sizeof(double));
	c1=(double *)malloc(imax*sizeof(double));
	d1=(double *)malloc(imax*sizeof(double));
	e1=(double *)malloc(imax*sizeof(double));
	q=(double *)malloc(imax*sizeof(double));
	v=(double *)malloc(imax*sizeof(double));
	u=(double *)malloc(imax*sizeof(double));
	y=(double *)malloc(imax*sizeof(double));

	for(k=0;k<2;k++)
	{
		for(i=2;i<imax-2;i++)
		{
			a1[i]=alpha;
			b1[i]=1.0;
			c1[i]=alpha;
			d1[i]=0.0;
			e1[i]=a/2.*(f[i+1]-f[i-1])+b/4.*(f[i+2]-f[i-2]);
		}
		if(boundary_flag) 
		{
			i=0;
			a1[i]=alpha;
			b1[i]=1.0;
			c1[i]=alpha;
			d1[i]=0;
			e1[i]=a/2.*(f[i+1]-f[imax-1])+b/4.*(f[i+2]-f[imax-2]);
			i=imax-1;
			a1[i]=alpha;
			b1[i]=1.0;
			c1[i]=alpha;
			d1[i]=0;
			e1[i]=a/2.*(f[0]-f[i-1])+b/4.*(f[1]-f[i-2]);
			i=1;
			a1[i]=alpha;
			b1[i]=1.0;
			c1[i]=alpha;
			d1[i]=0;
			e1[i]=a/2.*(f[i+1]-f[i-1])+b/4.*(f[i+2]-f[imax-1]);
			i=imax-2;
			a1[i]=alpha;
			b1[i]=1.0;
			c1[i]=alpha;
			d1[i]=0;
			e1[i]=a/2.*(f[imax-1]-f[i-1])+b/4.*(f[0]-f[i-2]);
		}
		for(i=0;i<imax;i++)
		{
			u[i]=0;
			v[i]=0;
		}
	/*	u[0]=b1[0];
		u[imax-1]=c1[imax-1];
		v[0]=1.0;
		v[imax-1]=a1[0]/b1[0];*/
	 	u[0]=1.;
		u[imax-1]=1.;
		v[0]=c1[imax-1];
		v[imax-1]=a1[0];

	 	b1[0]=b1[0]-v[0];
	 	b1[imax-1]=b1[imax-1]-v[imax-1];

		if(k==0)triad(a1,b1,c1,y,e1,imax);
		if(k==1)triad(a1,b1,c1,q,u,imax);
	}

	for(i=0;i<imax;i++)
	{
		temp1=temp1+v[i]*y[i];
		temp2=temp2+v[i]*q[i];
	}
	for(i=0;i<imax;i++)
	{
		fx[i]=y[i]-temp1/(1.0+temp2)*q[i];
	}
	fx[imax]=fx[0]; // Madhu
	if (a1!=NULL) free(a1);
	if (b1!=NULL)free(b1);
	if(c1!=NULL) free(c1);
	if(d1!=NULL) free(d1);
	if (e1!=NULL) free(e1);
	free(q);
	free(u);
	free(v);
	free(y);
	return 0;
}
int explicit4(double f[],double fx[],double dx,int imax,int boundary_flag)
{
	/*Boundary_flag (Default=0, Periodic=1, zero stress=2)*/
	double *a1,*b1,*c1,*d1,*e1;
	double temp1=0.0,temp2=0.0,temp3=0.0;
	int i;
	a1=(double *)malloc(imax*sizeof(double));
	b1=(double *)malloc(imax*sizeof(double));
	c1=(double *)malloc(imax*sizeof(double));
	d1=(double *)malloc(imax*sizeof(double));
	e1=(double *)malloc(imax*sizeof(double));
	for(i=2;i<imax-2;i++)
	{
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		d1[i]=0.0;
		e1[i]=(-f[i+2]+f[i-2]+8.0*f[i+1]-8.0*f[i-1])/12/dx;
	}

		i=0;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		d1[i]=0;
		e1[i]=(f[i+1]-f[i])/dx;
		i=imax-1;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		d1[i]=0;
		e1[i]=(f[i]-f[i-1])/dx;
		i=1;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		d1[i]=0;
		e1[i]=(f[i+1]-f[i-1])/2.0/dx;
		i=imax-2;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		d1[i]=0;
		e1[i]=(f[i+1]-f[i-1])/2.0/dx;;

	triad(a1,b1,c1,d1,e1,imax);

	for(i=0;i<imax;i++)
	{
		fx[i]=d1[i];
	}
	if (a1!=NULL) free(a1);
	if (b1!=NULL)free(b1);
	if(c1!=NULL) free(c1);
	if(d1!=NULL) free(d1);
	if (e1!=NULL) free(e1);
	return 0;
}
int explicit2(double f[],double fx[],double dx,int imax,int boundary_flag)
{
	/*Boundary_flag (Default=0, Periodic=1, zero stress=2)*/
	double *a1,*b1,*c1,*d1,*e1;
	double temp1=0.0,temp2=0.0,temp3=0.0;
	int i;
	a1=(double *)malloc(imax*sizeof(double));
	b1=(double *)malloc(imax*sizeof(double));
	c1=(double *)malloc(imax*sizeof(double));
	d1=(double *)malloc(imax*sizeof(double));
	e1=(double *)malloc(imax*sizeof(double));
	for(i=2;i<imax-2;i++)
	{
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		d1[i]=0.0;
		e1[i]=(f[i+1]-f[i-1])/2/dx;
	}

		i=0;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		d1[i]=0;
		e1[i]=(f[i+1]-f[i])/dx;
		i=imax-1;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		d1[i]=0;
		e1[i]=(f[i]-f[i-1])/dx;
		i=1;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		d1[i]=0;
		e1[i]=(f[i+1]-f[i-1])/2.0/dx;
		i=imax-2;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		d1[i]=0;
		e1[i]=(f[i+1]-f[i-1])/2.0/dx;;

	triad(a1,b1,c1,d1,e1,imax);

	for(i=0;i<imax;i++)
	{
		fx[i]=d1[i];
	}
	if (a1!=NULL) free(a1);
	if (b1!=NULL)free(b1);
	if(c1!=NULL) free(c1);
	if(d1!=NULL) free(d1);
	if (e1!=NULL) free(e1);
	return 0;
}

int compact55655(double f[],double fx[],double dx,int imax,int boundary_flag)
{
	/*Boundary_flag (Default=0, zero stress=2)*/
	double alpha=1./3., a=14.0/9.0, b=1.0/9.0;
	double *a1,*b1,*c1,*d1,*e1;
	double c[8],d[8],a0,b0,a11,b11;
//	double d0,d1,d2,d3,d4,d5,d6,d7;
	int i,j;
	a1=(double *)malloc(imax*sizeof(double));
	b1=(double *)malloc(imax*sizeof(double));
	c1=(double *)malloc(imax*sizeof(double));
	d1=(double *)malloc(imax*sizeof(double));
	e1=(double *)malloc(imax*sizeof(double));

	a0=1809.257;
	b0=-65.1944;
	a11=-262.16;
	b11=-26.6742;


	c[0]=-(a0-28*b0+13068.0)/5040.0;
	c[1]=+(a0-27*b0+05040.0)/0720.0;
    c[2]=-(a0-26*b0+02520.0)/0240.0;
	c[3]=+(a0-25*b0+01680.0)/0144.0;
	c[4]=-(a0-24*b0+01260.0)/0144.0;
    c[5]=+(a0-23*b0+01008.0)/0240.0;
	c[6]=-(a0-22*b0+00840.0)/0720.0;
	c[7]=+(a0-21*b0+00720.0)/5040.0;

	d[0]=-(a11-21*b11+0720.0)/5040.0;
	d[1]=+(a11-20*b11-1044.0)/0720.0;
    d[2]=-(a11-19*b11-0720.0)/0240.0;
	d[3]=+(a11-18*b11-0360.0)/0144.0;
	d[4]=-(a11-17*b11-0240.0)/0144.0;
    d[5]=+(a11-16*b11-0180.0)/0240.0;
	d[6]=-(a11-15*b11-0144.0)/0720.0;
	d[7]=+(a11-14*b11-0120.0)/5040.0;

	for(i=2;i<imax-2;i++)
	{
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		d1[i]=0.0;
		e1[i]=a/2.*(f[i+1]-f[i-1])+b/4.*(f[i+2]-f[i-2]);
	}
	if(boundary_flag==2)/* zero stress */
	{
		i=0;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=0.0;
		i=1;
		a1[i]=3.0/14.;
		b1[i]=1.0;
		c1[i]=3.0/14.;

	e1[i]=1./dx*(-19./28.*f[i-1]-5./42.*f[i]+6./7.*f[i+1]-1./14.*f[i+2]+1./84*f[i+3]);
		i=imax-2;
		a1[i]=2.0*1.0;
		b1[i]=1.0;
		c1[i]=0.0;
	 	e1[i]=-1./2./dx*(-5.0*f[i]+4.0*f[i-1]+f[i-2]);
		i=imax-1;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=0.0;
	}
	else		/* Default Boundary Condition */
	{
		i=0;
		a1[i]=0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=0.0;
		for(j=0;j<8;j++)
			e1[i]=e1[i]+c[j]*f[j]/dx;

		i=1;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=0.0;
		for(j=0;j<8;j++)
			e1[i]=e1[i]+d[j]*f[j]/dx;

	 	i=imax-1;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=0.0;
		for(j=0;j<8;j++)
			e1[i]=e1[i]-c[j]*f[imax-1-j]/dx;

		i=imax-2;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		e1[i]=0.0;
		for(j=0;j<8;j++)
			e1[i]=e1[i]-d[j]*f[imax-1-j]/dx;
	}
	triad(a1,b1,c1,d1,e1,imax);
	for(i=0;i<imax;i++)
	{
		fx[i]=d1[i];
	}
	free(a1);
	free(b1);
	free(c1);
	free(d1);
	free(e1);
	return 0;
}
int filter10p(double f[],double fx[],double dx,int imax,double alpha)
{
	double a00,a01,a02,a03,a04,a05;
	double a40,a41,a42,a43;

	double b12,b22,b32,b42,b52,b62,b72;
	double b13,b23,b33,b43,b53,b63,b73;

	double *a1,*b1,*c1,*d1,*e1;
	int i;
	a1=(double *)malloc(imax*sizeof(double));
	b1=(double *)malloc(imax*sizeof(double));
	c1=(double *)malloc(imax*sizeof(double));
	d1=(double *)malloc(imax*sizeof(double));
	e1=(double *)malloc(imax*sizeof(double));
	alpha=0.10;  //Madhu

	/* middle points */
	a00=      ( 193.+126.*alpha)/256.;
	a01=      ( 105.+302.*alpha)/256.;
	a02= 015.*(-001.+002.*alpha)/064.;
	a03= 045.*( 001.-002.*alpha)/512.;
	a04= 005.*(-001.+002.*alpha)/256.;
	a05=      ( 001.-002.*alpha)/512.;

	for(i=1;i<imax-1;i++)
	{
		a1[i]=alpha;
		b1[i]=1.0;
		c1[i]=alpha;
		d1[i]=0.0;
	}
	for(i=5;i<=imax-6;i++)
	{
		e1[i]=(a00*(f[i+0]+f[i-0])+
			   a01*(f[i+1]+f[i-1])+
			   a02*(f[i+2]+f[i-2])+
			   a03*(f[i+3]+f[i-3])+
			   a04*(f[i+4]+f[i-4])+
			   a05*(f[i+5]+f[i-5]))*0.5;
	}
	// Pre Boundary Points
	i=4;
	e1[i]=(a00*(f[i+0]+f[i-0])+
			a01*(f[i+1]+f[i-1])+
			a02*(f[i+2]+f[i-2])+
			a03*(f[i+3]+f[i-3])+
			a04*(f[i+4]+f[i-4])+
			a05*(f[i+5]+f[imax-2]))*0.5;
	i=3;
	e1[i]=(a00*(f[i+0]+f[i-0])+
			a01*(f[i+1]+f[i-1])+
			a02*(f[i+2]+f[i-2])+
			a03*(f[i+3]+f[i-3])+
			a04*(f[i+4]+f[imax-2])+
			a05*(f[i+5]+f[imax-3]))*0.5;
	i=2;
	e1[i]=(a00*(f[i+0]+f[i-0])+
			a01*(f[i+1]+f[i-1])+
			a02*(f[i+2]+f[i-2])+
			a03*(f[i+3]+f[imax-2])+
			a04*(f[i+4]+f[imax-3])+
			a05*(f[i+5]+f[imax-4]))*0.5;
	i=1;
	e1[i]=(a00*(f[i+0]+f[i-0])+
			a01*(f[i+1]+f[i-1])+
			a02*(f[i+2]+f[imax-2])+
			a03*(f[i+3]+f[imax-3])+
			a04*(f[i+4]+f[imax-4])+
			a05*(f[i+5]+f[imax-5]))*0.5;
	i=imax-5;
	e1[i]=(a00*(f[i+0]+f[i-0])+
			   a01*(f[i+1]+f[i-1])+
			   a02*(f[i+2]+f[i-2])+
			   a03*(f[i+3]+f[i-3])+
			   a04*(f[i+4]+f[i-4])+
			   a05*(f[1]+f[i-5]))*0.5;
	i=imax-4;
	e1[i]=(a00*(f[i+0]+f[i-0])+
			   a01*(f[i+1]+f[i-1])+
			   a02*(f[i+2]+f[i-2])+
			   a03*(f[i+3]+f[i-3])+
			   a04*(f[1]+f[i-4])+
			   a05*(f[2]+f[i-5]))*0.5;
	i=imax-3;
	e1[i]=(a00*(f[i+0]+f[i-0])+
			   a01*(f[i+1]+f[i-1])+
			   a02*(f[i+2]+f[i-2])+
			   a03*(f[1]+f[i-3])+
			   a04*(f[2]+f[i-4])+
			   a05*(f[3]+f[i-5]))*0.5;
	i=imax-2;
	e1[i]=(a00*(f[i+0]+f[i-0])+
			   a01*(f[i+1]+f[i-1])+
			   a02*(f[1]+f[i-2])+
			   a03*(f[2]+f[i-3])+
			   a04*(f[3]+f[i-4])+
			   a05*(f[4]+f[i-5]))*0.5;

/*Boundary Points 0,imax-1*/
		i=0;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		d1[i]=0.0;
		e1[i]=f[i];
		i=imax-1;
		a1[i]=0.0;
		b1[i]=1.0;
		c1[i]=0.0;
		d1[i]=0.0;
		e1[i]=f[0];


	triad(a1,b1,c1,d1,e1,imax);
	for(i=0;i<imax;i++)
	{
		fx[i]=d1[i];
	}
	if(a1!=NULL) free(a1);
	if(b1!=NULL)free(b1);
	if(c1!=NULL) free(c1);
	if(d1!=NULL) free(d1);
	if(e1!=NULL) free(e1);
	return 0;
}